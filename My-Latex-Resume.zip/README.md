<!--
 * @Author: Neary Lee
 * @Date: 2020-09-09 20:16:20
 * @LastEditTime: 2020-09-09 20:27:03
 * @LastEditors: Please set LastEditors
 * @Description: In User Settings Edit
 * @FilePath: \etherpad-litee:\Github\My-Latex-Resume\README.md
-->
# 个人简历
[![](https://img.shields.io/badge/version-v1.0-brightgreen.svg)]() ![](https://img.shields.io/badge/license-MIT-blue.svg)

### 本项目是利用Latex实现[PDF](https://github.com/Neary-li/My-Latex-Resume/blob/master/main.pdf)版个人简历

最终实现效果如下：


![Neary_Lee.jpg](https://i.loli.net/2020/09/09/vUN4HqFMkcXBrjg.jpg)

